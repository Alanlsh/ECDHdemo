//
//  ViewController.m
//  ECDHDemo
//
//  Created by Alan on 2019/7/16.
//  Copyright © 2019 Alan. All rights reserved.
//

#import "ViewController.h"
#import "MEWcryptoImplementation.h"
#import "MEWcryptoMessage.h"
#import "NSString+HexData.h"
#import "NSData+Hexadecimal.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   

        NSData *ivData = [@"ce7e8b6bab2e491a069bcced0324dab8" parseHexData];
        NSData *ephemPublicKeyData = [@"04f112c635c3a1c3b159bc9cdbad1c8a49b6afea71222f82a7f679f2e6a3284a983ea37d90a3176f68002c219e71c10a3449f6ad0f50c35c1f25d1788e9b4aa26f" parseHexData];
        NSData *cipherData = [@"4230c5b32d24dd0f8ac9731f22705d59" parseHexData];
        NSData *macData = [@"7f9d77697c759c61d5478d8e22fa03179ba90ca203379e6e32846dbf260decf6" parseHexData];
    
        MEWcryptoMessage *cryptoMessage = [MEWcryptoMessage messageWithIV:ivData ephemPublicKey:ephemPublicKeyData cipher:cipherData mac:macData];
    
        MEWcryptoImplementation *cryptoImplementation = [[MEWcryptoImplementation alloc] init];
        [cryptoImplementation configurateWithConnectionPrivateKey:[@"e0092f723ba5ef3468d6010a2153ddcb1c2a1244fcf68085d7fb6a1059b88501" parseHexData]];
    
        NSData *data = [cryptoImplementation decryptMessage:cryptoMessage];
    
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
   
    MEWcryptoMessage *cryptoMessage1 = [cryptoImplementation encryptMessage:[@"ce7e8b6bab2e491a069bcced0324dab8" parseHexData]];
    
    
    
    
    
}


@end
