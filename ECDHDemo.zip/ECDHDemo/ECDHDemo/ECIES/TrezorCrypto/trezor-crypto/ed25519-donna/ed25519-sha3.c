#include <stddef.h>

#include "ed25519-sha3.h"
#include "ed25519-hash-custom-sha3.h"

#define ED25519_SUFFIX _sha3

#include "ed25519.c"
