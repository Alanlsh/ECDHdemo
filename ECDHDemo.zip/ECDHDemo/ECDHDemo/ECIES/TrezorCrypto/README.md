# TrezorCrypto iOS

A CocoaPods wrapper around the [trezor-crypto](https://github.com/trezor/trezor-crypto) C library.

To install it simply add the following line to your Podfile:

```
pod 'TrezorCrypto'
```
