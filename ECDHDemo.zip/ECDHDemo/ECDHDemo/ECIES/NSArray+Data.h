//
//  NSArray+Data.h
//  MyEtherWallet-iOS
//
//  Created by Mikhail Nikanorov on 19/06/2018.
//  Copyright © 2018 MyEtherWallet, Inc. All rights reserved.
//

@import Foundation;

@interface NSArray (Data)
- (NSData *) convertToData;
@end
